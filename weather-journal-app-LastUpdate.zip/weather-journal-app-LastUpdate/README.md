# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI 
by current weather data ,current date and user's feeling that is in the text box

## Instructions
server.js file
first we install express,cors and body-parser then we require them
we made a listening function when the server is running print server running on port.. in console
we made a get function to get all data and another to post.
website/app.js file
start with definning all global variables
function toGenerate run by clicking on button generate and get zip code ,date ,content
function to post data to server called postInServer when response is ok then update ui otherwise make alert
function updateUI to update data of date,temp,feel in inner HTML